package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

import Model.Receitas;

/**
 *
 * @author Marcus 29/12/2022
 */
public class ReceitasDAO {

    public ReceitasDAO() throws ClassNotFoundException{
        conn = new Conexao().getConexao();
    }

    public PreparedStatement preparedStatement;
    public Connection conn;
    public ResultSet resultSet;
    private ArrayList<Receitas> lista = new ArrayList<>();

    public void inserir(Receitas receita) {

        String sql = "INSERT INTO receita"
                + "(nome, detalhe, data)"
                + "VALUES(?,?,?)";

        try {
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, receita.getNome());
            preparedStatement.setString(2, receita.getDetalhes());
            preparedStatement.setString(3, receita.getData());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "ReceitaDAO.inserir --> " + erro.getMessage());
        }
    }

    public void alterar(Receitas receita) {

        String sql = "UPDATE receita SET nome=?, detalhe=?, data=? WHERE idReceita=?";
        try {
            preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, receita.getNome());
            preparedStatement.setString(2, receita.getDetalhes());
            preparedStatement.setString(3, receita.getData());
            preparedStatement.setInt(4, receita.getIdReceita());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ReceitaDAO.alterar --> " + erro.getMessage());

        }
    }

    public ArrayList<Receitas> listar() {

        String sql = "SELECT * FROM receita";
        //pega do banco, joga no model e depois exibi na tela.
        try {
            preparedStatement = conn.prepareStatement(sql);
            //Todo o conteudo que trazer do banco tem que usar o ResultSet
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) { //enquanto estiver proximo, ainda estiver dados nas linhas da tabela
                Receitas receita = new Receitas();
                receita.setIdReceita(resultSet.getInt("idReceita"));
                receita.setNome(resultSet.getString("nome"));
                receita.setDetalhes(resultSet.getString("detalhe"));
                receita.setData(resultSet.getString("data"));

                lista.add(receita);
            }

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ReceitaDAO.listar --> " + erro.getMessage());

        }
        return lista;
    }

    public void deletar(Receitas receita) {

        String sql = "DELETE FROM receita WHERE idReceita = ?";
        try {
            preparedStatement = conn.prepareStatement(sql);

            preparedStatement.setInt(1, receita.getIdReceita());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "ReceitaDAO.deletar --> " + erro.getMessage());
        }
    }
}
