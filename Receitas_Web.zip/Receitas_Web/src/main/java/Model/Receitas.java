package Model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class Receitas {
	
	private int idReceita;
	private String nome;
	private String detalhes;
	private Date data;
	
	public Receitas() {

	}

	public int getIdReceita() {
		return idReceita;
	}

	public void setIdReceita(int idReceita) {
		this.idReceita = idReceita;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDetalhes() {
		return detalhes;
	}

	public void setDetalhes(String detalhes) {
		this.detalhes = detalhes;
	}

	public String getData() {
		return new SimpleDateFormat("dd/MM/yyyy").format(this.data);

	}

	public void setData(String data) {
        try {
            this.data = new SimpleDateFormat("dd/MM/yyyy").parse(data);
        } catch (Exception erro) {
            JOptionPane.showMessageDialog(null, "Receita.setDATA --> " + erro.getMessage());
        }
	}
	
	

}
